# importing liblary
import pywhatkit

# convert img to ascii..,,, Bisa di pakak untuk png jpg 
pywhatkit.image_to_ascii_art('nama_gambar.jpg', 'resultArt')