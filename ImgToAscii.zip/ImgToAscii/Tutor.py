import sys
from time import sleep

def tutor(s):
    for c in s + '\n':
        sys.stdout.write(c)
        sys.stdout.flush()
        sleep(8. / 100)
        
        
        
tutor("""\033[32mKalian rename file kalian jadi simple aja kayak jjj.jpg atau jjj.png\nlalu kalian copy dari storage kalian ke folder ini dan kalian copy si file jjj.png/jjj.jpg\ndan kalian ketikan nano imgToAsciiArt.py dan kalian di bagian pywhatkit.image_to_ascii_art('nama_gambar.jpg', 'resultArt')\nganti nama_gambar.jpg jadi nama file foto kalian yang udh di simple kan lalu kalian jalankan
""")